package lc.propertyEditior;

import java.beans.PropertyEditorSupport;

public class NamePropertyEditior extends PropertyEditorSupport{

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		     String upperCase = text.toUpperCase();
		     setValue(upperCase);
	}

	
}
