package lc.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


import lc.DTO.api.UserRegistrationDTO;

public class EmailValidator  implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return UserRegistrationDTO.class.equals(clazz);
	}

	@Override
	public void validate(Object object, Errors errors) {
		//to validate email email cannot empty and only accept ending with @seleniumexpres.com
		 
		 String email1 = ((UserRegistrationDTO)object).getCommunicationDTO().getEmail();
		      ValidationUtils.rejectIfEmptyOrWhitespace(errors, "communicationDTO.email", "email.empty");
		    if(!email1.endsWith("@seleniumexpres.com")) {
		    	errors.rejectValue("communicationDTO.email", "email.invalid","email ends with @seleniumexpres.com");
		    }
	}

}
