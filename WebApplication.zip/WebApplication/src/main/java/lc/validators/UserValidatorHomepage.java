package lc.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import lc.DTO.api.UserInfoDTO;

public class UserValidatorHomepage implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		
		return UserInfoDTO.class.equals(clazz);
	}

	@Override
	public void validate(Object object, Errors errors) {
		
		    String name= ( (UserInfoDTO)object).getUsername();
		    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "username.empty","username cannot empty");
		    
		    if(!name.contains("_")){
		     errors.rejectValue("username", "username.invalid String","username can contain underscore");	
	}

}
}
