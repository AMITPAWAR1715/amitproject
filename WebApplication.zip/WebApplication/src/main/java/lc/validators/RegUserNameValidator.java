package lc.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import lc.DTO.api.CommunicationDTO;
import lc.DTO.api.UserRegistrationDTO;

public class RegUserNameValidator implements Validator {
//check if the usernamevalidator supports s given object
	@Override
	public boolean supports(Class<?> clazz) {
	
		return UserRegistrationDTO.class.equals(clazz);
	}
//we need to write our custom validation logic
	@Override
	public void validate(Object object, Errors errors) {
		//username cannot be empty
	 ValidationUtils.rejectIfEmptyOrWhitespace(errors,"username", "username.empty", "username cannot be empty");
		//username can contain underscore
	  String username=(( UserRegistrationDTO)object).getUsername();
	  if(!username.contains("_")) {
		  errors.rejectValue("username", "username.invalidString", "string should contain underscore");
	  }
	  
	  
	
	}
	
	
}
