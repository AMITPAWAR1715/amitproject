package lc.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import lc.DTO.api.UserInfoDTO;

public class AgreeTermAndConditionValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
	
		return UserInfoDTO.class.equals(clazz);
	}

	@Override
	public void validate(Object object, Errors errors) {
		   
		boolean termAndCondition11 = ((UserInfoDTO)object).isTermAndCondition();
		if(termAndCondition11==false)
		{
			ValidationUtils.rejectIfEmpty(errors, "termAndCondition", "u have to agree term and condition");
		}
		
	}

}
