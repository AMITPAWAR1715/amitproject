package lc.DTO.api;

public class UserInfoDTO {
	
   
	 private String username;
	
	 private String personname;

	 private boolean termAndCondition;
	 
	 private String result;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPersonname() {
		return personname;
	}
	public void setPersonname(String personname) {
		this.personname = personname;
	}
	

	
	public boolean isTermAndCondition() {
		return termAndCondition;
	}
	public void setTermAndCondition(boolean termAndCondition) {
		this.termAndCondition = termAndCondition;
	}
	
	@Override
	public String toString() {
		return "UserInfoDTO [username=" + username + ", personname=" + personname + "]";
	}
	
	
}
