package lc.DTO.api;

public class Phone {
	private String countryCode;
	private String userNumer;
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getUserNumer() {
		return userNumer;
	}
	public void setUserNumer(String userNumer) {
		this.userNumer = userNumer;
	}
	@Override
	public String toString() {
		return getCountryCode()+"-"+getUserNumer();
	}
	
	
}
