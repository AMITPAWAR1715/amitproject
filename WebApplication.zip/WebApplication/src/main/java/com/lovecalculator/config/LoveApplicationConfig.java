package com.lovecalculator.config;

import java.util.Properties;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.FormatterRegistry;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import formatter.PhoneNumberFormatter;
@EnableWebMvc
@Configuration
@ComponentScan(basePackages = {"instagram.controller","lcAppServiceLayer"})
//@PropertySource("classpath:email.properties")
public class LoveApplicationConfig implements WebMvcConfigurer {
	
	@Bean
	public InternalResourceViewResolver viewResolver() {
		 InternalResourceViewResolver a=new InternalResourceViewResolver();
		 a.setPrefix("/WEB-INF/view/");
		 a.setSuffix(".jsp");
		return a;
		 
	 }
	@Bean
	public JavaMailSender getConfigurationJavaMail() {
		JavaMailSenderImpl javaMailSenderImpl=new JavaMailSenderImpl();
		javaMailSenderImpl.setHost("smtp.gmail.com");
		javaMailSenderImpl.setUsername("lovecalulatorapp@gmail.com");
		javaMailSenderImpl.setPassword("huld oiro etrl dcxo");
		javaMailSenderImpl.setPort( 587 );
		Properties prop=new Properties();
		prop.put("mail.smtp.starttls.enable", true);
		prop.put("mail.smtp.ssl.trust", "smtp.gmail.com");
	     javaMailSenderImpl.setJavaMailProperties(prop);
		return javaMailSenderImpl ;
		
	}
	
	
	@Override
	public void addFormatters(FormatterRegistry registry) {
		registry.addFormatter(new PhoneNumberFormatter());
	}
	

}
