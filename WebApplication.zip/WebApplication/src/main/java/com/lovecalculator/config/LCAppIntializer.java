package com.lovecalculator.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class LCAppIntializer extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override
	protected Class<?>[] getRootConfigClasses() {
		
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		Class[]a= {LoveApplicationConfig.class};
		return a;
	}

	@Override
	protected String[] getServletMappings() {
		String[]map= {"/"};
		return map;
	}

}
