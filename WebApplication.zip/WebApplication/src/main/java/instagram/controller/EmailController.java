package instagram.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import lc.DTO.api.EmailDTO;
import lc.DTO.api.UserInfoDTO;
import lcAppServiceLayer.LcAppEmailServiceImpl;


@Controller
public class EmailController {
	@Autowired
	LcAppEmailServiceImpl lcAppEmailServiceImpl;
   @RequestMapping("/sendEmail")
	public String sendEmail( String username ,Model model) {
	 
	   model.addAttribute("EmailDTO", new EmailDTO());
		return"send-email-page";
	}
   
   @RequestMapping("/process-email")
  	public String processEmail(@SessionAttribute("userinfo") UserInfoDTO userInfoDTO,  @ModelAttribute("EmailDTO") EmailDTO emailDTO) {
	   
	  lcAppEmailServiceImpl.sendEmail(userInfoDTO.getUsername(),emailDTO.getUserEmail(),"FRIEND");
	   
	
  		return"process-email-page";
  	}
}
