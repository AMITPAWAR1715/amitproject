package instagram.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import lc.DTO.api.UserInfoDTO;
import lc.validators.AgreeTermAndConditionValidator;
import lc.validators.UserValidatorHomepage;
import lcAppServiceLayer.LCAppServiceImpl;

@Controller
@SessionAttributes("userinfo")
public class LCController {
	@Autowired
	LCAppServiceImpl lcAppServiceImpl;
	@RequestMapping("/")
	public String showHomePage(Model model )
	
	{
		model.addAttribute("userinfo", new UserInfoDTO());
	   
		
		
		
		return "home-page";
	}
	
	@RequestMapping("/process-homepage")
	public String showResult( UserInfoDTO userinfoDTO ,Model model,BindingResult result) {
	model.addAttribute("userinfo", userinfoDTO);
		if(result.hasErrors()) {
			System.out.println("your  from has error....");
			return "home-page";
		}
		
		String appResult=   lcAppServiceImpl.calculateLove(userinfoDTO.getUsername(), userinfoDTO.getPersonname());
             userinfoDTO.setResult(appResult);
	
		return "return-page";	
	     
		
}
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.addValidators(new UserValidatorHomepage());
		binder.addValidators( new AgreeTermAndConditionValidator() );
	}
}
