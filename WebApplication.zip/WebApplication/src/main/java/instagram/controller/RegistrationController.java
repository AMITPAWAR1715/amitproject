package instagram.controller;

import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import lc.DTO.api.UserRegistrationDTO;
import lc.propertyEditior.NamePropertyEditior;
import lc.validators.EmailValidator;
import lc.validators.RegUserNameValidator;

@Controller
public class RegistrationController {
	@RequestMapping("/register")
	public String showRegistrationPage( @ModelAttribute("userReg")UserRegistrationDTO rs) {
		
		return "user-registration-page";
		
	}
	@RequestMapping("/registration-success")
	public String ResgistrationSuccess(  @ModelAttribute("userReg")UserRegistrationDTO rs ,BindingResult res)
	{
		if(res.hasErrors()) {
			//System.out.println("username has error username cannot be empty");
			return"user-registration-page";
		}
		return"registration-success";
	}
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		//binder.setDisallowedFields("name");
		StringTrimmerEditor editor=new StringTrimmerEditor(true);
		binder.registerCustomEditor(String.class,"name", editor);
		
		NamePropertyEditior namePropertyEditior=new NamePropertyEditior();
		binder.registerCustomEditor(String.class,"name", namePropertyEditior);
		
		binder.addValidators(new RegUserNameValidator());
		binder.addValidators(new EmailValidator());
		
	}

}
