package formatter;

import java.text.ParseException;
import java.util.Locale;

import org.springframework.format.Formatter;

import lc.DTO.api.Phone;

public class PhoneNumberFormatter implements Formatter<Phone> {

	@Override
	public String print(Phone object, Locale locale) {
		
		return null;
	}

	@Override
	public Phone parse(String completePhoneNumber, Locale locale) throws ParseException {
		Phone a=new Phone();
		String[] split = completePhoneNumber.split("-");
	int ch= completePhoneNumber.indexOf('-');
	if(ch==-1 || completePhoneNumber.startsWith("-")) {
		a.setCountryCode("91");
		
		if(completePhoneNumber.startsWith("-")) {
			a.setUserNumer(split[1]);
		}
		else {
			a.setUserNumer(split[0]);
		}
	}
	else {
		a.setCountryCode(split[0]);
		a.setUserNumer(split[1]);
		
	}
		
return a;
	} 

}
