package lcAppServiceLayer;

public interface LCAppService {
	public String calculateLove(String username,String personname);
	public String whatBetweenUs(char calculationResult);
	

}
