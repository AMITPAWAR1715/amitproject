package lcAppServiceLayer;

public interface LcAppEmailService {
	
	public void sendEmail(String username,String userEmail,String result);

}
