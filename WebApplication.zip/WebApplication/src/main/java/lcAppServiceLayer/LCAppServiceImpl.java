package lcAppServiceLayer;

import org.springframework.stereotype.Service;

@Service
public class LCAppServiceImpl implements LCAppService {

	public final String LC_APP_FORMULA="FLAMEBS";
	@Override
	public String  calculateLove(String username, String personname) {
		 int userAndPersonnameCount=    (username+personname).toCharArray().length;
		  int formulaCount= LC_APP_FORMULA.toCharArray().length;
		  int rem=userAndPersonnameCount%formulaCount;
		  
		char resultChar=  LC_APP_FORMULA.charAt(rem);
		
	String result=	 whatBetweenUs(resultChar);
		return result;
		  
		 
		
	}
	@Override
	public String whatBetweenUs(char calculationResult) {
		String result=null;
		if(calculationResult=='F') {
			result=LoveCalculatorConstant.F_CHAR_MEANING;
		}
		else if(calculationResult=='L') {
			result=LoveCalculatorConstant.L_CHAR_MEANING;
		}
		else if(calculationResult=='A') {
			result=LoveCalculatorConstant.A_CHAR_MEANING;
		}
		else if(calculationResult=='M') {
			result=LoveCalculatorConstant.M_CHAR_MEANING;
		}
		else if(calculationResult=='E') {
			result=LoveCalculatorConstant.E_CHAR_MEANING;
		}
		else if(calculationResult=='S') {
			result=LoveCalculatorConstant.S_CHAR_MEANING;
		}
		else if(calculationResult=='B') {
			result=LoveCalculatorConstant.B_CHAR_MEANING;
		}
		
		return result;
	}

}
