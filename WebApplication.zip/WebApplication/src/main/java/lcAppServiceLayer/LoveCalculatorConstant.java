package lcAppServiceLayer;

public class LoveCalculatorConstant {
	
	public static final String F_CHAR_MEANING="FRIEND";
	public static final String L_CHAR_MEANING="LOVE";
	public static final String M_CHAR_MEANING="MARRIAGE";
	public static final String A_CHAR_MEANING="AFFECTION";
	public static final String E_CHAR_MEANING="ENIMY";
	public static final String S_CHAR_MEANING="SISTER";
	public static final String B_CHAR_MEANING="BROTHER";

}
