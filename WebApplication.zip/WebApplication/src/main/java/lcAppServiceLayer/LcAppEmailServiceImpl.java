package lcAppServiceLayer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class LcAppEmailServiceImpl implements LcAppEmailService {
	@Autowired
	private JavaMailSender javaMailSender;

	@Override
	public void sendEmail(String username, String userEmail, String result) {
		SimpleMailMessage newEmail=new SimpleMailMessage();
		newEmail.setTo(userEmail);
		newEmail.setSubject("Love Calculator Application Result ");
		newEmail.setText("Hi "+username+" and   The Result Predicted By Love Calculator of is You Are :FRIEND");
		
		javaMailSender.send(newEmail);
		
		
	}

}
